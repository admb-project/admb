compare.beta <- function()
{
  dat <- scan("betacomp.dat",com='#')
  nx <- as.integer(dat[1])
  b <- dat[2]
  x <- dat[3]
  print(paste(nx,b,x))
  beta <- matrix(dat[4:(length(dat)-3)],ncol=3,byrow=T)
  colnames(beta)<-c("a", "AD","cephes")
  print(head(beta))
  #R <- vector(length=nx)
  #for (i in 1:nx)
  #{
    #R[i] <- pbeta(x, beta[i,"a"], b)
  #}
  R <- pbeta(x, beta[,"a"], b)
  plot(beta[,"a"],beta[,"AD"],type = 'l',xlab="A",ylab="inc beta")
  points(beta[,"a"],beta[,"cephes"],col="blue",pch='+')
  points(beta[,"a"],R,col="red")
  lines(beta[,"a"],beta[,"AD"],lwd=3)

  dev.copy2pdf(file="beta-comp.pdf")
}
