#include <fvar.hpp>
extern "C" {
static double incbet(double, double, double);
}

int main(void)
{
  double x1=1.9999;
  double x2 = 2.0001;
  double x0 = 1.99;  
  double y0 = 0.4;   // aka b
  double z0 = 0.25;  // aka x

  double dx = 0.000002;
  int nx = (x2-x1)/dx + 1;
  double xx = 0.0;
  ofstream bet("betacomp.dat");
  bet << "#  n b  x" << endl;
  bet << nx << " " << y0 <<  " " << z0 << endl;
  bet << "# a  AD  cephes" << endl;
  for (int i = 1; i <= nx; i++)
  {
    xx =  xx + dx;
    double ad = betai(xx,y0,z0);
    double cephes = incbet(xx,y0,z0);
  
    bet << xx << " " << ad << " " << cephes << endl;
  }
  return(0);
}

