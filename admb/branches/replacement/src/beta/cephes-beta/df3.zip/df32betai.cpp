
  
  #include <df1b2fun.h>
  #include <admodel.h>
  #include <df12fun.h>
  #include <df32fun.h>
  #include <df3fun.h>
  #define EPS 3.0e-7
  #define FPMIN 1.0e-30
  #define MAXIT 100
     
  
  df3_two_variable betacf(df3_two_variable& a, df3_two_variable& b, 
    double x);
  df3_two_variable betacf(df3_two_variable& a, double b, df3_two_variable& x);
    
  df3_two_variable betacf(double a,df3_two_variable& b,df3_two_variable&  x);
  df3_two_variable gammln(const df3_two_variable& xx);

  df3_two_variable betai(df3_two_variable& a,df3_two_variable& b,double x,
    int maxit)
  {
    df3_two_variable bt;
  
    if (x < 0.0 || x > 1.0) cerr << "Bad x in routine betai" << endl;
    if (x == 0.0 || x == 1.0) bt=0.0;
    else
      bt=exp(gammln(a+b)-gammln(a)-gammln(b)+a*log(x)+b*log(1.0-x));
    if (x < (value(a)+1.0)/(value(a)+value(b)+2.0))
      return bt*betacf(a,b,x)/a;
    else
      return 1.0-bt*betacf(b,a,1.0-x)/b;
  }
    
  df3_two_variable betai(df3_two_variable& a,double b,df3_two_variable& x,
    int maxit)
  {
    df3_two_variable bt;
  
    if (value(x) < 0.0 || value(x) > 1.0) cerr << "Bad x in routine betai" << endl;
    if (value(x) == 0.0 || value(x) == 1.0) bt=0.0;
    else
      bt=exp(gammln(a+b)-gammln(a)-gammln(b)+a*log(x)+b*log(1.0-x));
    if (value(x) < (value(a)+1.0)/(value(a)+b+2.0))
      return bt*betacf(a,b,x)/a;
    else
      return 1.0-bt*betacf(b,a,1.0-x)/b;
  }
    
  df3_two_variable betai(double a,df3_two_variable& b,df3_two_variable& x,
    int maxit)
  {
    df3_two_variable bt;
  
    if (value(x) < 0.0 || value(x) > 1.0) cerr << "Bad x in routine betai" << endl;
    if (value(x) == 0.0 || value(x) == 1.0) bt=0.0;
    else
      bt=exp(gammln(a+b)-gammln(a)-gammln(b)+a*log(x)+b*log(1.0-x));
    if (value(x) < (a+1.0)/(a+value(b)+2.0))
      return bt*betacf(a,b,x)/a;
    else
      return 1.0-bt*betacf(b,a,1.0-x)/b;
  }
    
  
  df3_two_variable betacf(df3_two_variable& a, df3_two_variable& b, 
    double x)
  {
    int m,m2;
    df3_two_variable aa,c,d,del,h,qab,qam,qap;
     
    qab=a+b;
    qap=a+1.0;
    qam=a-1.0;
    c=1.0;
    d=1.0-qab*x/qap;
    if (fabs(value(d)) < FPMIN) d=FPMIN;
    d=1.0/d;
    h=d;
    for (m=1;m<=MAXIT;m++) 
    {
      m2=2*m;
      aa=m*(b-m)*x/((qam+m2)*(a+m2));
      d=1.0+aa*d;
      if (fabs(value(d)) < FPMIN) d=FPMIN;
      c=1.0+aa/c;
      if (fabs(value(c)) < FPMIN) c=FPMIN;
      d=1.0/d;
      h *= d*c;
      aa = -(a+m)*(qab+m)*x/((a+m2)*(qap+m2));
      d=1.0+aa*d;
      if (fabs(value(d)) < FPMIN) d=FPMIN;
      c=1.0+aa/c;
      if (fabs(value(c)) < FPMIN) c=FPMIN;
      d=1.0/d;
  
      del=d*c;
      h *= del;
      if (fabs(value(del)-1.0) < EPS) break;
    }
    if (m > MAXIT) 
    {
      cerr << "mum interations exceeded " << endl;
      ad_exit(1);
    }
    return h;
  }
  
  
  df3_two_variable betacf(double a,df3_two_variable& b,df3_two_variable&  x)
  {
    int m,m2;
    df3_two_variable aa,c,d,del,h,qab,qam,qap;
     
    qab=a+b;
    qap=a+1.0;
    qam=a-1.0;
    c=1.0;
    d=1.0-qab*x/qap;
    if (fabs(value(d)) < FPMIN) d=FPMIN;
    d=1.0/d;
    h=d;
    for (m=1;m<=MAXIT;m++) 
    {
      m2=2*m;
      aa=m*(b-m)*x/((qam+m2)*(a+m2));
      d=1.0+aa*d;
      if (fabs(value(d)) < FPMIN) d=FPMIN;
      c=1.0+aa/c;
      if (fabs(value(c)) < FPMIN) c=FPMIN;
      d=1.0/d;
      h *= d*c;
      aa = -(a+m)*(qab+m)*x/((a+m2)*(qap+m2));
      d=1.0+aa*d;
      if (fabs(value(d)) < FPMIN) d=FPMIN;
      c=1.0+aa/c;
      if (fabs(value(c)) < FPMIN) c=FPMIN;
      d=1.0/d;
  
      del=d*c;
      h *= del;
      if (fabs(value(del)-1.0) < EPS) break;
    }
    if (m > MAXIT) 
    {
      cerr << "mum interations exceeded " << endl;
      ad_exit(1);
    }
    return h;
  }
  
  df3_two_variable betacf(df3_two_variable& a, double b, df3_two_variable& x) 
  {
    int m,m2;
    df3_two_variable aa,c,d,del,h,qab,qam,qap;
     
    qab=a+b;
    qap=a+1.0;
    qam=a-1.0;
    c=1.0;
    d=1.0-qab*x/qap;
    if (fabs(value(d)) < FPMIN) d=FPMIN;
    d=1.0/d;
    h=d;
    for (m=1;m<=MAXIT;m++) 
    {
      m2=2*m;
      aa=m*(b-m)*x/((qam+m2)*(a+m2));
      d=1.0+aa*d;
      if (fabs(value(d)) < FPMIN) d=FPMIN;
      c=1.0+aa/c;
      if (fabs(value(c)) < FPMIN) c=FPMIN;
      d=1.0/d;
      h *= d*c;
      aa = -(a+m)*(qab+m)*x/((a+m2)*(qap+m2));
      d=1.0+aa*d;
      if (fabs(value(d)) < FPMIN) d=FPMIN;
      c=1.0+aa/c;
      if (fabs(value(c)) < FPMIN) c=FPMIN;
      d=1.0/d;
  
      del=d*c;
      h *= del;
      if (fabs(value(del)-1.0) < EPS) break;
    }
    if (m > MAXIT) 
    {
      cerr << "mum interations exceeded " << endl;
      ad_exit(1);
    }
    return h;
  }
  

static df3_two_variable gammlnguts(const df3_two_variable& z)
{
  df3_two_variable x;
  const double lpi =1.1447298858494001741434272;
  const double pi =3.1415926535897932384626432;
  const double lpp =0.9189385332046727417803297;
  int n=7;
  const double c[9]={0.99999999999980993, 
    676.5203681218851, 
    -1259.1392167224028,
     771.32342877765313, 
    -176.61502916214059, 
    12.507343278686905,
     -0.13857109526572012, 
    9.9843695780195716e-6, 
    1.5056327351493116e-7};
  z-=0.0;
  z-=1.0;
  x=c[0];
  for (int i=1;i<=n+1;i++)
  {
    df3_two_variable zinv=1.0/(z+i);
    x+=c[i]*zinv;
  }    
  df3_two_variable t=z+n+0.5;
  df3_two_variable ans= lpp + (z+0.5)*log(t) -t + log(x);
  return(ans);
}

df3_two_variable gammln(const df3_two_variable& z)
{
  const double lpi =1.1447298858494001741434272;
  const double pi =3.1415926535897932384626432;
  if (value(z)<0.5)
  {
    return lpi - log(sin(pi*z)) - gammlnguts(1.0-z);
  }
  else
  {
    return gammlnguts(z);
  }
}
  
