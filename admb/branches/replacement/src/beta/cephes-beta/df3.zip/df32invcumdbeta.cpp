
#include <df1b2fun.h>
#include <admodel.h>
#include <df12fun.h>

//#define ADUNCONST(type,obj) type & obj = (type&) _##obj;

static double lnbeta(double a,double b)
{
  return gammln(a)+gammln(b)-gammln(a+b);
}

static int sgn(double z)
{
  if (z>=0)
    return 1;
  else
    return -1;
}

df1_two_variable betai(df1_two_variable a,df1_two_variable b,double x,
  int maxit=50);

double inv_cumd_beta(double _a,double _b,double _y);
double inv_cumd_beta_stable(double _a,double _b,double _y,double eps);

dvariable inv_cumd_beta(const prevariable& _a,const prevariable& _b,
  const prevariable& _y)
{
  ADUNCONST(prevariable,a);
  ADUNCONST(prevariable,b);
  ADUNCONST(prevariable,y);

  // this gets the inverse without derivatives
  double ca=value(a);
  double cb=value(b);
  double cx=inv_cumd_beta(ca,cb,value(y));

  init_df1_two_variable va(_a);
  init_df1_two_variable vb(_b);

  // this gets the derivatives for the function itself
  df1_two_variable z=betai(va,vb,cx,25);
   
  double dga=*z.get_u_x();
  double dgb=*z.get_u_y();

  double dgx=pow(cx,value(a)-1.0)*pow(1.0-cx,value(b)-1.0)/
    exp(lnbeta(value(a),value(b)));

  // now solve for the derivatves of the inverse function

  double dfx=1.0/dgx;
  double dfa=-dfx*dga;
  double dfb=-dfx*dgb;

  dvariable tmp;
  value(tmp)=cx;

  gradient_structure::GRAD_STACK1->set_gradient_stack(default_evaluation3ind,
    &(value(tmp)) ,&(value(_a)),dfa ,&(value(_b)),dfb ,&(value(_y)),dfx);

  return tmp;
}

dvariable inv_cumd_beta_stable(const prevariable& _a,const prevariable& _b,
  const prevariable& _y,double eps)
{
  ADUNCONST(prevariable,a);
  ADUNCONST(prevariable,b);
  ADUNCONST(prevariable,y);

  double eps1=1.0-eps;
  // this gets the inverse without derivatives
  double ca=value(a);
  double cb=value(b);
  double cx=inv_cumd_beta_stable(ca,cb,value(y),eps);

  init_df1_two_variable va(_a);
  init_df1_two_variable vb(_b);

  // this gets the derivatives for the function itself

  df1_two_variable z=(betai(va,vb,cx,25)-betai(va,vb,eps,25))/
    (betai(va,vb,eps1,25)-betai(va,vb,eps,25));
   
  double dga=*z.get_u_x();
  double dgb=*z.get_u_y();

  double denom=1.0/(betai(ca,cb,eps1)-betai(ca,cb,eps));
  double dgx=pow(cx,value(a)-1.0)*pow(1.0-cx,value(b)-1.0)/
    exp(lnbeta(value(a),value(b)))*denom;

  // now solve for the derivatves of the inverse function

  double dfx=1.0/dgx;
  double dfa=-dfx*dga;
  double dfb=-dfx*dgb;

  dvariable tmp;
  value(tmp)=cx;

  gradient_structure::GRAD_STACK1->set_gradient_stack(default_evaluation3ind,
    &(value(tmp)) ,&(value(_a)),dfa ,&(value(_b)),dfb ,&(value(_y)),dfx);

  return tmp;
}

df1_two_variable betacf(df1_two_variable& a, df1_two_variable& b, 
  double& x);
  

df1_two_variable betai(df1_two_variable a,df1_two_variable b,double x,
  int maxit)
{
  df1_two_variable bt;

  if (x < 0.0 || x > 1.0) cerr << "Bad x in routine betai" << endl;
  if (x == 0.0 || x == 1.0) bt=0.0;
  else
    bt=exp(gammln(a+b)-gammln(a)-gammln(b)+a*log(x)+b*log(1.0-x));
  if (x < (value(a)+1.0)/(value(a)+value(b)+2.0))
    return bt*betacf(a,b,x)/a;
  else
    return 1.0-bt*betacf(b,a,1.0-x)/b;
}
  
main()
{
  double a,b,x;

  a=2.0;
  b=3.0; 
  x=.80;
  do
  {
    cin >> a;
    cin >> b;
    cin >> x;
    if (x<0 ) exit(1);
    independent_variables xx(1,3);
    dvector g(1,3);
    dvector gg(1,3);
    xx(1)=a;
    xx(2)=b;
    xx(3)=x;
    gradient_structure gs(10000);
    {
      dvar_vector vx=dvar_vector(xx);
      dvariable y=inv_cumd_beta(vx(1),vx(2),vx(3));
      cout << y << endl;
      gradcalc(3,g);
      double h=1.e-6;
      gg(1)=(inv_cumd_beta(a+h,b,x)-inv_cumd_beta(a-h,b,x))/(2.0*h);
      gg(2)=(inv_cumd_beta(a,b+h,x)-inv_cumd_beta(a,b-h,x))/(2.0*h);
      gg(3)=(inv_cumd_beta(a,b,x+h)-inv_cumd_beta(a,b,x-h))/(2.0*h);
      cout << g << endl  << gg << " " << endl << g-gg << endl;
    }
    {
      dvar_vector vx=dvar_vector(xx);
      dvariable y=inv_cumd_beta_stable(vx(1),vx(2),vx(3),1.e-7);
      cout << y << endl;
      gradcalc(3,g);
      double h=1.e-6;
      gg(1)=(inv_cumd_beta_stable(a+h,b,x,1.e-7)-inv_cumd_beta_stable(a-h,b,x,1.e-7))/
        (2.0*h);
      gg(2)=(inv_cumd_beta_stable(a,b+h,x,1.e-7)-inv_cumd_beta_stable(a,b-h,x,1.e-7))/
        (2.0*h);
      gg(3)=(inv_cumd_beta_stable(a,b,x+h,1.e-7)-inv_cumd_beta_stable(a,b,x-h,1.e-7))/
        (2.0*h);
      cout << g << endl  << gg << " " << endl << g-gg << endl;
    }
  }
  while(1);
}


#include <math.h>
#define MAXIT 100
#define EPS 3.0e-7
#define FPMIN 1.0e-30
   
df1_two_variable betacf(df1_two_variable& a, df1_two_variable& b, 
  double& x)
{
  int m,m2;
  df1_two_variable aa,c,d,del,h,qab,qam,qap;
   
  qab=a+b;
  qap=a+1.0;
  qam=a-1.0;
  c=1.0;
  d=1.0-qab*x/qap;
  if (fabs(value(d)) < FPMIN) d=FPMIN;
  d=1.0/d;
  h=d;
  for (m=1;m<=MAXIT;m++) 
  {
    m2=2*m;
    aa=m*(b-m)*x/((qam+m2)*(a+m2));
    d=1.0+aa*d;
    if (fabs(value(d)) < FPMIN) d=FPMIN;
    c=1.0+aa/c;
    if (fabs(value(c)) < FPMIN) c=FPMIN;
    d=1.0/d;
    h *= d*c;
    aa = -(a+m)*(qab+m)*x/((a+m2)*(qap+m2));
    d=1.0+aa*d;
    if (fabs(value(d)) < FPMIN) d=FPMIN;
    c=1.0+aa/c;
    if (fabs(value(c)) < FPMIN) c=FPMIN;
    d=1.0/d;

    del=d*c;
    h *= del;
    if (fabs(value(del)-1.0) < EPS) break;
  }
  if (m > MAXIT) 
  {
    cerr << "mum interations exceeded " << endl;
    ad_exit(1);
  }
  return h;
}
#undef MAXIT
#undef EPS
#undef FPMIN



df1_two_variable gammln(const df1_two_variable& xx)
{
  df1_two_variable x,tmp,ser;
  static double cof[6]={76.18009173,-86.50532033,24.01409822,
    -1.231739516,0.120858003e-2,-0.536382e-5};
  int j;
  x=xx-1.0;
  tmp=x+5.5;
  tmp -= (x+0.5)*log(tmp);
  ser=1.0;
  for (j=0;j<=5;j++) 
  {
    x += 1.0;
    ser += cof[j]/x;
  }
  return -tmp+log(2.50662827465*ser);
}


